import tkinter as tk

# Estado inicial
current_player = "X"
board = ["-"] * 9

# Função para verificar vitória
def check_winner():
    combos = [(0,1,2),(3,4,5),(6,7,8),
              (0,3,6),(1,4,7),(2,5,8),
              (0,4,8),(2,4,6)]
    for a,b,c in combos:
        if board[a] == board[b] == board[c] and board[a] != "-":
            return board[a]
    return None

# Função chamada ao clicar no botão
def button_click(i):
    global current_player
    if board[i] == "-":
        board[i] = current_player
        buttons[i].config(text=current_player)
        winner = check_winner()
        if winner:
            status_label.config(text=f"Jogador {winner} venceu!")
            disable_buttons()
        elif "-" not in board:
            status_label.config(text="Empate!")
        else:
            current_player = "O" if current_player == "X" else "X"
            status_label.config(text=f"Vez do jogador {current_player}")

# Desabilitar botões após fim do jogo
def disable_buttons():
    for b in buttons:
        b.config(state="disabled")

# Criar janela
root = tk.Tk()
root.title("Jogo da Velha")

# Criar botões do tabuleiro
buttons = []
for i in range(9):
    b = tk.Button(root, text="-", width=10, height=3,
                  command=lambda i=i: button_click(i))
    b.grid(row=i//3, column=i%3)
    buttons.append(b)

# Label de status
status_label = tk.Label(root, text="Vez do jogador X")
status_label.grid(row=3, column=0, columnspan=3)

root.mainloop()
